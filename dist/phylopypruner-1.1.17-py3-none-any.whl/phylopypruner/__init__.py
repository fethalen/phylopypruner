"""
PhyloPyPruner is a tree-based program for orthology inference. Please see the
Wiki for details (https://gitlab.com/fethalen/phylopypruner/wikis).
"""
