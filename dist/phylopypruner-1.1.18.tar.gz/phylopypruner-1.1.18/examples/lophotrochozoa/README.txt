This is a small subset of the data generated for the paper Lophotrochozoa with
Consideration of Systematic Error
(link to paper: https://www.ncbi.nlm.nih.gov/pubmed/27664188;
DOI: 10.1093/sysbio/syw079).
