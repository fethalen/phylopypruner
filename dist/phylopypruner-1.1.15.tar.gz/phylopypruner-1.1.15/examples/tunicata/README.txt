This is a small subset of the data generated for the paper Phylogenomics offers
resolution of major tunicate relationships
(link to paper: https://www.ncbi.nlm.nih.gov/pubmed/29330139;
DOI: 10.1016/j.ympev.2018.01.005).
